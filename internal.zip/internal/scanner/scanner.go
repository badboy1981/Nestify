package scanner

import (
	"os"
	"path/filepath"

	"github.com/badboy1981/Nestify/internal/ignore"
	"github.com/badboy1981/Nestify/internal/pathutil"
	"github.com/badboy1981/Nestify/internal/types"
)

// Scan walks a project path with optional max depth and ignore filtering.
func Scan(path string, foldersOnly bool, maxDepth int) ([]types.Node, error) {
	osPath := pathutil.NormalizeForOS(path)
	info, err := os.Stat(osPath)
	if err != nil {
		return nil, err
	}

	standardRoot := pathutil.ToStandardPath(osPath)

	// Ignore matcher loads rules from the project root (not dependent on subfolders).
	matcher, err := ignore.NewIgnoreMatcher(standardRoot)
	if err != nil {
		return nil, err
	}

	rootNode := types.Node{
		Name: filepath.Base(standardRoot),
		Type: "folder",
		Size: info.Size(),
	}

	// Start scanning at depth 1.
	children, err := scanDir(standardRoot, standardRoot, matcher, foldersOnly, 1, maxDepth)
	if err != nil {
		return nil, err
	}
	rootNode.Children = children

	return []types.Node{rootNode}, nil
}

func scanDir(currentPath, rootPath string, matcher *ignore.IgnoreMatcher, foldersOnly bool, currentDepth, maxDepth int) ([]types.Node, error) {
	entries, err := os.ReadDir(currentPath)
	if err != nil {
		return nil, err
	}

	var nodes []types.Node
	for _, entry := range entries {
		if foldersOnly && !entry.IsDir() {
			continue
		}

		entryName := entry.Name()
		fullPath := filepath.Join(currentPath, entryName)

		relPath, _ := filepath.Rel(rootPath, fullPath)
		standardRel := pathutil.ToStandardPath(relPath)

		if matcher != nil {
			// Check both base name and relative path against ignore rules.
			if matcher.ShouldIgnore(entryName, entry.IsDir()) || matcher.ShouldIgnore(standardRel, entry.IsDir()) {
				continue
			}
		}

		info, _ := entry.Info()
		var size int64
		if info != nil {
			size = info.Size()
		}

		node := types.Node{
			Name: entryName,
			Size: size,
		}

		if entry.IsDir() {
			node.Type = "folder"
			if maxDepth <= 0 || currentDepth < maxDepth {
				children, err := scanDir(fullPath, rootPath, matcher, foldersOnly, currentDepth+1, maxDepth)
				if err != nil {
					return nil, err
				}
				node.Children = children
			}
		} else {
			node.Type = "file"
		}
		nodes = append(nodes, node)
	}
	return nodes, nil
}
